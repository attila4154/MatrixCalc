#include "hdr/CApplication.h"

int main () {
    CApplication app;
    app.Run();
}