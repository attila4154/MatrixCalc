#pragma once 
#include <map>
#include <string>
#include <memory>

#define CMemory std::map <std::string, std::shared_ptr<CExpr>>
