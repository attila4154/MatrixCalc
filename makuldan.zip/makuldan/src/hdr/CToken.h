#pragma once

#include <iostream>
#include <vector>
#include <sstream>
#include <queue>
#include <stack>

#include "CMatrix.h"
#include "CDense.h"
#include "CSparse.h"
#include "define.h"

class CExpr;

/*
    token class has 4 derived classes:
    -matrix, variable, operator, brackets
*/

class CToken {
  public:
    enum TokenType {
        Nothing,
        Operator,
        Matrix,
        Number,
        LeftBracket,
        RightBracket,
        Variable
    };
    CToken                           (int t);
    int                   GetType   (void)               const;
    virtual void          Print     (std::ostream & out) const = 0; 
    virtual MPtr          Value     ();
    virtual std::string * GetName   ();
    friend std::ostream & operator << (std::ostream & out, const CToken & t);
  protected:
    int type = TokenType::Nothing;
};
//=========================================================
class CMatrixToken : public CToken {
  public:
    CMatrixToken (const CMatrix & m);
    CMatrixToken (CMatrix * m);
    CMatrixToken (std::shared_ptr<CMatrix> m);
    CMatrixToken (float number);
    MPtr Value  () override;
    void Print  (std::ostream & out) const;
    ~CMatrixToken () {}
  private:
    MPtr matrix;
};
//=========================================================
class COperatorToken : public CToken {
public:
    COperatorToken (char sign, int prec);
    void Print (std::ostream & out) const;
    int Precedence ();
    std::shared_ptr<CMatrixToken> Calculate 
    (MPtr left, MPtr right, CMemory & matrices);
    MPtr Sum  (const CMatrix & left, const CMatrix & right);
    MPtr Sub  (const CMatrix & left, const CMatrix & right);
    MPtr Mult (const CMatrix & left, const CMatrix & right);
private:
    char op;
    int precedence;
};
//=========================================================
class CBracketsToken : public CToken {
  public:
    CBracketsToken   (char b);
    void Print (std::ostream & out) const;
  private:
    bool isLeftBr;
};
//=========================================================
/**
  variable class contains only name of the variable
*/
class CVariableToken : public CToken {
  public:
    CVariableToken        (const std::string & name);
    std::string * GetName () override;
    void Print            (std::ostream & out) const;
  private:
    std::string varName;
};
//--------------------------------------------------------
